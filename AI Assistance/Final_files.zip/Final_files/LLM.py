from openai import OpenAI

client = OpenAI(
    api_key="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",
    base_url="https://openrouter.ai/api/v1"
)


system_prompt = """
You are Avanti, a voice assistant designed to help a user
navigate and interact with their environment.

Your job is to understand the user's spoken command and
respond clearly and briefly.

Rules:

- Keep responses short and natural because your response
  will be spoken aloud using text-to-speech.
- Do not use markdown, bullet points, emojis, or special formatting.
- Do not invent information that you do not know.
- If the user's request is unclear, ask a short clarification question.
- Give direct answers instead of unnecessary explanations.
- Never describe visual information unless it is provided to you.
- When information about detected objects, distances, or directions
  is provided, use that information directly.
- Do not make up distances, object positions, or environmental information.
"""


# Avanti's memory
memory = [
    {
        "role": "system",
        "content": system_prompt
    }
]


def get_completion(
    prompt,
    model="openai/gpt-4o-mini"
):

    # Add user's message to memory
    memory.append({
        "role": "user",
        "content": prompt
    })

    response = client.chat.completions.create(
        model=model,
        messages=memory,
        temperature=0
    )

    answer = response.choices[0].message.content

    # Add Avanti's response to memory
    memory.append({
        "role": "assistant",
        "content": answer
    })

    return answer

