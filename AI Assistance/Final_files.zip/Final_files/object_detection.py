from ultralytics import YOLO
import cv2

model = YOLO("best.pt")


def object_detection(camera):

    while True:

        ret, frame = camera.read()

        if not ret:
            return False

        results = model.predict(frame, verbose=False)

        height, width, _ = frame.shape

        for r in results:

            for box in r.boxes:

                x, y, w, h = box.xywh[0]

                # Object name
                class_id = int(box.cls[0])
                class_name = model.names[class_id]

                # Current bounding box area
                area = w * h

                # Direction
                if x < width / 3:
                    direction = "LEFT"

                elif x < 2 * width / 3:
                    direction = "MIDDLE"

                else:
                    direction = "RIGHT"

                # Approximate distance
                if area < 20000:
                    distance_status = "FAR"

                elif area < 60000:
                    distance_status = "MEDIUM"

                else:
                    distance_status = "CLOSE"

                # Bounding box
                x1 = int(x - w / 2)
                y1 = int(y - h / 2)

                x2 = int(x + w / 2)
                y2 = int(y + h / 2)

                cv2.rectangle(
                    frame,
                    (x1, y1),
                    (x2, y2),
                    (0, 255, 0),
                    2
                )

                cv2.putText(
                    frame,
                    f"{class_name} | {direction} | {distance_status}",
                    (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (0, 255, 0),
                    2
                )

        cv2.imshow("Avanti Object Detection", frame)

        # Press Q to exit detection mode
        if cv2.waitKey(1) == ord("q"):
            cv2.destroyWindow("Avanti Object Detection")
            return True